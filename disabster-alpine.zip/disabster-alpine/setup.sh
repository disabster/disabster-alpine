#!/bin/ash

echo "========== step1  ================"
./step1.sh
echo "========== step2  ================"
./step2.sh
echo "========== step3  ================"
./step3.sh

